# starlord
Bucketlist Blockchain

Using Flask, MySQL, Python
