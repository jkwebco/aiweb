# Scikit-learn + Flask Example

Welcome to my Scikit-learn + Flask Example! This project demonstrates how to train and deploy a simple model. Using a red wine dataset, I create a model that can predict wine quality. Other applications can use this model through a single route server. This project is composed of two python files: a model training script and the web server.

Most of the explaining is found in my article [here](https://medium.freecodecamp.org/a-beginners-guide-to-training-and-deploying-machine-learning-models-using-python-48a313502e5a).